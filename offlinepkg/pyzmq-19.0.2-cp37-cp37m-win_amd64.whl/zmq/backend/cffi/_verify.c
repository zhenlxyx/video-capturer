#include <stdio.h>
#include <string.h>

#include <zmq.h>
#include "zmq_compat.h"

#include "ipcmaxlen.h"
